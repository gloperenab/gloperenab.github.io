function modificar(id){
	location.href = ("actualizar.php?id="+id);
}

function eliminar(id){
	
}