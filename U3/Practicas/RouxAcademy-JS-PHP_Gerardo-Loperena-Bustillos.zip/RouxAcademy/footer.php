<footer>
	<img src="images/ralogo_monogram.png">
	<p>
		Join over 500 hundred of the most creative and brilliant minds of art colleges all 
		around the world for three days of lectures by world-renowned art scholars and artists.
	</p>
	<div>
		<ul>
			<li style="border-right: 1px solid"><a href="about.html">About the Roux Academy</a></li>
			<li style="border-right: 1px solid"><a href="policy.html">Privacy Policy</a></li>
			<li><a href="index.html">Visit our web site</a></li>
		</ul>
	</div><!-- fin enlaces footer -->
</footer>